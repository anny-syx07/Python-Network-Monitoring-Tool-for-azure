import os
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route("/api/log", methods=["POST"])
def log_data():
    data = request.json
    print(data) 
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)